package com.example.klinikrawatjalan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
