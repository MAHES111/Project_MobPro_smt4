import 'package:flutter/material.dart';
import 'package:klinikrawatjalan/widget/Sidebar.dart';
import '../widget/Sidebar.dart';
import 'HalamanReservasi.dart';

class Beranda extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    String namaUser = 'Nama Pasien'; // Ganti dengan nama pengguna yang sesuai
    String emailUser =
        'emailpasien@mail.com'; // Ganti dengan email pengguna yang sesuai

    return Scaffold(
      appBar: AppBar(
        title: Text('Beranda'),
      ),
      drawer: Sidebar(
          namaUser: namaUser,
          emailUser: emailUser), // Tampilkan sidebar di sini
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // Baris pertama
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Kotak 1: Dokter Umum
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              HalamanReservasi(jenisDokter: 'Dokter Umum')),
                    );
                  },
                  child: Container(
                    width: 150,
                    height: 150,
                    color: Color(0xff17a140),
                    child: Center(
                      child: Text(
                        'Dokter Umum',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 18),
                      ),
                    ),
                  ),
                ),
                // Kotak 2: Dokter Spesialis Mata
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => HalamanReservasi(
                              jenisDokter: 'Dokter Spesialis Mata')),
                    );
                  },
                  child: Container(
                    width: 150,
                    height: 150,
                    color: Color(0xff43aef0),
                    child: Center(
                      child: Text(
                        'Dokter Spesialis Mata',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 18),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20), // Jarak antara baris pertama dan kedua
            // Baris kedua
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Kotak 3: Bidan dan Kandungan
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => HalamanReservasi(
                              jenisDokter:
                                  'Bidan dan\nKandungan')), // Ubah agar 'Bidan dan Kandungan' menjadi dua baris
                    );
                  },
                  child: Container(
                    width: 150,
                    height: 150,
                    color: Color(0xff6ddb42),
                    child: Center(
                      child: Text(
                        'Bidan dan\nKandungan',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 18),
                      ),
                    ),
                  ),
                ),
                // Kotak 4: Dokter Spesialis Jantung
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => HalamanReservasi(
                              jenisDokter: 'Dokter Spesialis Jantung')),
                    );
                  },
                  child: Container(
                    width: 150,
                    height: 150,
                    color: Color(0xff149a12),
                    child: Center(
                      child: Text(
                        'Dokter Spesialis Jantung',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 18),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
                height: 20), // Jarak antara baris kedua dengan elemen lainnya
            // Baris ketiga
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Kotak 5: Dokter Spesialis Kulit
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => HalamanReservasi(
                              jenisDokter: 'Dokter Spesialis Kulit')),
                    );
                  },
                  child: Container(
                    width: 150,
                    height: 150,
                    color: Color(0xff1b9b45),
                    child: Center(
                      child: Text(
                        'Dokter Spesialis Kulit',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 18),
                      ),
                    ),
                  ),
                ),
                // Kotak 6: Dokter Spesialis Kejiwaan
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => HalamanReservasi(
                              jenisDokter: 'Dokter Spesialis Kejiwaan')),
                    );
                  },
                  child: Container(
                    width: 150,
                    height: 150,
                    color: Color(0xff49a0f7),
                    child: Center(
                      child: Text(
                        'Dokter Spesialis Kejiwaan',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 18),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
                height: 20), // Jarak antara baris ketiga dengan elemen lainnya
          ],
        ),
      ),
    );
  }
}
