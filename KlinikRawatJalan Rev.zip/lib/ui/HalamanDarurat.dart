import 'package:flutter/material.dart';

class HalamanDarurat extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Panggilan Darurat'),
      ),
      body: Center(
        child: GestureDetector(
          onTap: () {
            // Aksi ketika tombol ditekan
            showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text('Konfirmasi Panggilan Darurat'),
                  content: Text(
                      'Apakah Anda yakin ingin melakukan panggilan darurat ke rumah sakit terdekat?'),
                  actions: <Widget>[
                    TextButton(
                      child: Text('Batal'),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                    TextButton(
                      child: Text('Ya, Panggil Sekarang'),
                      onPressed: () {
                        Navigator.of(context).pop(); // Tutup dialog
                      },
                    ),
                  ],
                );
              },
            );
          },
          child: Container(
            width: 200,
            height: 200,
            color: Colors.red,
            child: Center(
              child: Text(
                'Panggil Rumah Sakit Terdekat',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
