import 'package:flutter/material.dart';

class HalamanUpdatePasien extends StatefulWidget {
  @override
  _HalamanUpdatePasienState createState() => _HalamanUpdatePasienState();
}

class _HalamanUpdatePasienState extends State<HalamanUpdatePasien> {
  TextEditingController namaController = TextEditingController();
  TextEditingController teleponController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kelola Akun'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // Ubah Nama
            Text('Ubah Nama:', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            TextField(
              controller: namaController,
              decoration: InputDecoration(
                hintText: 'Masukkan Nama Baru',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            // Ubah No Telepon
            Text('Ubah No Telepon:', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            TextField(
              controller: teleponController,
              decoration: InputDecoration(
                hintText: 'Masukkan No Telepon Baru',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            // Ubah Email
            Text('Ubah Email:', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                hintText: 'Masukkan Email Baru',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            // Ubah Password
            Text('Ubah Password:', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Masukkan Password Baru',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            // Tombol Simpan
            ElevatedButton(
              onPressed: () {
                // Aksi untuk menyimpan perubahan
                simpanPerubahan();
              },
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  void simpanPerubahan() {
    String namaBaru = namaController.text;
    String teleponBaru = teleponController.text;
    String emailBaru = emailController.text;
    String passwordBaru = passwordController.text;

    // Tampilkan pesan sukses atau navigasi kembali ke halaman sebelumnya
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Perubahan disimpan')),
    );

    // Setelah berhasil, kosongkan kembali nilai di controller
    namaController.clear();
    teleponController.clear();
    emailController.clear();
    passwordController.clear();
  }
}
