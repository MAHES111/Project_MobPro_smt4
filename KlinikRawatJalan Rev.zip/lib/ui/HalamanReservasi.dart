import 'package:flutter/material.dart';

class HalamanReservasi extends StatefulWidget {
  final String jenisDokter;

  HalamanReservasi({required this.jenisDokter});

  @override
  _HalamanReservasiState createState() => _HalamanReservasiState();
}

class _HalamanReservasiState extends State<HalamanReservasi> {
  String namaUser = '';
  String tanggal = '';
  String waktu = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reservasi untuk ${widget.jenisDokter}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Jam Tersedia: 09:00 - 21:00',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'Masukan Nama:',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 5),
            TextField(
              decoration: InputDecoration(
                hintText: 'Masukkan nama Anda',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {
                  namaUser = value;
                });
              },
            ),
            SizedBox(height: 20),
            Text(
              'Masukan Tanggal:',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 5),
            TextField(
              decoration: InputDecoration(
                hintText: 'Masukkan tanggal reservasi',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {
                  tanggal = value;
                });
              },
            ),
            SizedBox(height: 20),
            Text(
              'Masukan Waktu:',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 5),
            TextField(
              decoration: InputDecoration(
                hintText: 'Masukkan waktu reservasi',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {
                  waktu = value;
                });
              },
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('Reservasi Berhasil'),
                      content: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                              'Terima kasih, $namaUser, reservasi untuk ${widget.jenisDokter} pada tanggal $tanggal dan jam $waktu telah berhasil.'),
                          SizedBox(height: 10),
                          Text(
                              'Kami akan segera mengkonfirmasi reservasi Anda.'),
                        ],
                      ),
                      actions: <Widget>[
                        TextButton(
                          child: Text('Tutup'),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),
                      ],
                    );
                  },
                );
              },
              child: Text('Reservasi'),
            ),
          ],
        ),
      ),
    );
  }
}
