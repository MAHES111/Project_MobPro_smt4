import 'package:flutter/material.dart';
import 'package:klinikrawatjalan/ui/Beranda.dart';
import 'package:klinikrawatjalan/ui/HalamanDarurat.dart';
import 'package:klinikrawatjalan/widget/Sidebar.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Sidebar Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Beranda(), // Ganti dengan halaman utama aplikasi
    );
  }
}
