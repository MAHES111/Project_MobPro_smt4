import 'package:flutter/material.dart';
import '../ui/Beranda.dart';
import '../ui/HalamanDarurat.dart';
import '../ui/HalamanUpdatePasien.dart';

class Sidebar extends StatelessWidget {
  final String namaUser;
  final String emailUser;

  Sidebar({required this.namaUser, required this.emailUser});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  namaUser, // Tampilkan nama pengguna di sini
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  emailUser, // Tampilkan email pengguna di sini
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
          ListTile(
            title: Text('Beranda'),
            onTap: () {
              Navigator.pop(context); // Tutup sidebar setelah dipilih
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Beranda()),
              );
            },
          ),
          ListTile(
            title: Text('Panggilan Darurat'),
            onTap: () {
              Navigator.pop(context); // Tutup sidebar setelah dipilih
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HalamanDarurat()),
              );
            },
          ),
          ListTile(
            title: Text('Kelola Akun'),
            onTap: () {
              Navigator.pop(context); // Tutup sidebar setelah dipilih
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HalamanUpdatePasien()),
              );
            },
          ),
          ListTile(
            title: Text(
              'Keluar',
              style: TextStyle(color: Colors.red),
            ),
            onTap: () {
              Navigator.pop(context); // Tutup sidebar setelah dipilih
              // Tambahkan logika untuk keluar dari akun (logout) jika diperlukan
            },
          ),
        ],
      ),
    );
  }
}
